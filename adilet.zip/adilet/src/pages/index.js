export * from './AboutPage';
export * from './MainPage';
export * from './PokemonInfo'